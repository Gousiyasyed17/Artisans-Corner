import API from "./api";

export const getDashboard = async () => {
  const { data } = await API.get("/admin/dashboard");
  return data.dashboard;
};

export const getOrders = async () => {
  const { data } = await API.get("/admin/orders");
  return data.orders;
};

export const getUsers = async () => {
  const { data } = await API.get("/admin/users");
  return data.users;
};

export const getProducts = async () => {
  const { data } = await API.get("/admin/products");
  return data.products;
};

export const getAnalytics = async () => {
  const { data } = await API.get("/admin/analytics");
  return data.analytics;
};